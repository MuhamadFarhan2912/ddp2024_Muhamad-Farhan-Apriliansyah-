class gempa:
    #kontraktor inisialisasi atribut dan skala
    def __init__(self, lokasi, skala):

        #atribut
        self.lokasi=lokasi
        self.skala=skala

    #method menentukan dampak skala gempa
    def dampak(self):

        #stetment/logika
        if self.skala < 2:
            print('dampak gempa tidak berasa')
        elif self.skala >=2 and self.skala <= 4:
            print('dampak gempa bangunan retak-retak ')
        elif self.skala > 4 and self.skala <=6:
            print('dampak gempa bangunan roboh dan berpotensi tsunami')
        elif self.skala > 6:
            print('tsunami')

        #menampilkan lokasi dan skala
        print(f'lokasi gempa: {self.lokasi}')
        print(f'lokasi gempa: {self.skala}')
