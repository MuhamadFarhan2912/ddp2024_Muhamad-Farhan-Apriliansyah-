from latihan_12animal import *

class Ikan(animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna, bisa):
        super().__init__(nama, makanan, hidup, berkembang_biak)  # Memanggil konstruktor kelas induk
        self.warna = warna
        self.bisa = bisa

    def info_fish(self):
        print(f"Nama                 : {self.nama}")
        print(f"Makanan              : {self.makanan}")
        print(f"Hidup                : {self.hidup}")
        print(f"Berkembang biak      : {self.berkembang_biak}")
        print(f"Warna                : {self.warna}")
        print(f"Jenis bisa          : {self.bisa}")
        print()  # Tambahkan baris kosong untuk pemisah antar ikan

class Ular(animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna, bisa):
        super().__init__(nama, makanan, hidup, berkembang_biak)  # Memanggil konstruktor kelas induk
        self.warna = warna
        self.bisa = bisa

    def info_ular(self):
        print(f"Nama                 : {self.nama}")
        print(f"Makanan              : {self.makanan}")
        print(f"Hidup                : {self.hidup}")
        print(f"Berkembang biak      : {self.berkembang_biak}")
        print(f"Warna                : {self.warna}")
        print(f"Jenis bisa          : {self.bisa}")
        print()  # Tambahkan baris kosong untuk pemisah antar ular

# Contoh penggunaan
ikan1 = Ikan("Ikan Mas", "Serangga", "3 tahun", "bertelur", "emas", "tidak berbisa")
ikan1.info_fish()

ular1 = Ular("Ular Kobra", "Mamalia kecil", "10 tahun", "bertelur", "hitam", "berbisa")
ular1.info_ular()

ular2 = Ular("Ular Sanca", "Burung", "20 tahun", "bertelur", "coklat", "tidak berbisa")
ular2.info_ular()